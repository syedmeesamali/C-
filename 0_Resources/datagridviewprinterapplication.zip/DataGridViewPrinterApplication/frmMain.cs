using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;

namespace DataGridViewPrinterApplication
{
    public partial class frmMain : Form
    {
        DataGridViewPrinter MyDataGridViewPrinter;

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // Please be sure of the database path, I suppose it will be in the same folder where the application exe file is in (usually should be in 'YourProjectPath\bin\debug')
            string MyConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + Application.StartupPath + "\\Customers.mdb";

            // Generating the DataSet and the DataAdapter
            DataSet ds = new DataSet();
            // All 'Customers' table's columns could fit in one page
            //OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM Customers", MyConnectionString);
            // All 'Customers2' table's columns could fit in two page
            OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM Customers2", MyConnectionString);
            try
            {
                da.Fill(ds, "dt");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Operation failed: " + ex.ToString(), Application.ProductName + " - Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Setting the style of the DataGridView control
            MyDataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Tahoma", 9, FontStyle.Bold, GraphicsUnit.Point);
            MyDataGridView.ColumnHeadersDefaultCellStyle.BackColor = SystemColors.ControlDark;
            MyDataGridView.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            MyDataGridView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            MyDataGridView.DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Regular, GraphicsUnit.Point);
            MyDataGridView.DefaultCellStyle.BackColor = Color.Empty;
            MyDataGridView.AlternatingRowsDefaultCellStyle.BackColor = SystemColors.ControlLight;
            MyDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            MyDataGridView.GridColor = SystemColors.ControlDarkDark;

            // Binding the DataGridViewControl to the DataSet generated above
            MyDataGridView.DataSource = ds;
            MyDataGridView.DataMember = "dt";

            // Changing the last column alignment to be in the Right alignment            
            MyDataGridView.Columns[MyDataGridView.Columns.Count - 1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            // Adjusting each column to be fit as the content of all its cells, including the header cell
            MyDataGridView.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            //MyDataGridView.Columns[0].Visible = false;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {            
            if (SetupThePrinting())
                MyPrintDocument.Print();
        }

        private void MyPrintDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            bool more = MyDataGridViewPrinter.DrawDataGridView(e.Graphics);
            if (more == true)
                e.HasMorePages = true;
        }

        private void btnPrintPreview_Click(object sender, EventArgs e)
        {
            if (SetupThePrinting())
            {
                PrintPreviewDialog MyPrintPreviewDialog = new PrintPreviewDialog();
                MyPrintPreviewDialog.Document = MyPrintDocument;
                MyPrintPreviewDialog.ShowDialog();
            }
        }

        private bool SetupThePrinting()
        {
            PrintDialog MyPrintDialog = new PrintDialog();
            MyPrintDialog.AllowCurrentPage = false;
            MyPrintDialog.AllowPrintToFile = false;
            MyPrintDialog.AllowSelection = false;
            MyPrintDialog.AllowSomePages = false;
            MyPrintDialog.PrintToFile = false;
            MyPrintDialog.ShowHelp = false;
            MyPrintDialog.ShowNetwork = false;

            if (MyPrintDialog.ShowDialog() != DialogResult.OK)
                return false;

            MyPrintDocument.DocumentName = "Customers Report";
            MyPrintDocument.PrinterSettings = MyPrintDialog.PrinterSettings;
            MyPrintDocument.DefaultPageSettings = MyPrintDialog.PrinterSettings.DefaultPageSettings;
            MyPrintDocument.DefaultPageSettings.Margins = new Margins(40, 40, 40, 40);

            if (MessageBox.Show("Do you want the report to be centered on the page", "InvoiceManager - Center on Page", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                MyDataGridViewPrinter = new DataGridViewPrinter(MyDataGridView, MyPrintDocument, true, true, "Customers", new Font("Tahoma", 18, FontStyle.Bold, GraphicsUnit.Point), Color.Black, true);
            else
                MyDataGridViewPrinter = new DataGridViewPrinter(MyDataGridView, MyPrintDocument, false, true, "Customers", new Font("Tahoma", 18, FontStyle.Bold, GraphicsUnit.Point), Color.Black, true);

            return true;
        }
    }
}